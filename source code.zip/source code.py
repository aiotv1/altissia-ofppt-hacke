from rich.console import Console
from rich.markdown import Markdown
from colorama import Fore, Back, Style
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time
import re
import pickle
import os
import pygetwindow as gw
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from PIL import ImageTk, Image
import webbrowser

vrs = 1,0,1

# إنشاء كائن Console
console = Console()

print("(ctrl + click) to enter to the website")
# نص مع رابط
markdown_text = "[update here](https://github.com/aiotv1/altissia-ofppt-hacke)"

# عرض النص في التيرمينال
markdown = Markdown(markdown_text)
console.print(markdown)

print("")
print("virsion " , vrs)
print("")

# تعريف المتغير message_box كمتغير عام
message_box = None

def update_function():
    # الشيء الذي تريد فعله عند النقر على زر "Update"
    # هنا يمكنك وضع الرابط الذي تريد الانتقال إليه
    webbrowser.open("https://github.com/aiotv1/altissia-ofppt-hacke")  # ضع هنا الرابط الذي تريد استخدامه


def hide_message_box():
    global message_box
    # التحقق من أن message_box معرف
    if message_box is not None:
        # إخفاء نافذة "GO"
        message_box.withdraw()

def starttt():

    # الحصول على البريد الإلكتروني وكلمة المرور من مدخلات النص
    email = email_entry.get()
    passw = password_entry.get()
    
    # إنشاء مثيل لمتصفح WebDriver (مثال باستخدام Chrome)
    driver = webdriver.Chrome()

    answers_list = []

    # انتظار حتى يظهر عنصر معين على الصفحة
    def wait_until_element_visible(driver, by, locator):
        return WebDriverWait(driver, 20).until(
            EC.visibility_of_element_located((by, locator))
        )

    # انتظار حتى يتم تحميل الصفحة بشكل كامل
    def wait_until_page_loaded(driver):
        return WebDriverWait(driver, 20).until(
            lambda driver: driver.execute_script('return document.readyState') == 'complete'
        )




    try:
        # فتح صفحة الويب المستهدفة
        driver.get("https://app.ofppt-langues.ma/gw/api/saml/init?idp=https://sts.windows.net/dae54ad7-43df-47b7-ae86-4ac13ae567af/")

        # انتظار تحميل الصفحة بشكل كامل
        wait_until_page_loaded(driver)

        # إدخال البريد الإلكتروني
        email_field = wait_until_element_visible(driver, By.ID, "i0116")
        email_field.send_keys(email)

        # النقر على زر تسجيل الدخول
        login_button = wait_until_element_visible(driver, By.ID, "idSIButton9")
        login_button.click()

        # انتظار تحميل الصفحة بشكل كامل
        wait_until_page_loaded(driver)

        # إدخال كلمة المرور
        password_field = wait_until_element_visible(driver, By.ID, "i0118")
        password_field.send_keys(passw)

        # النقر على زر تسجيل الدخول
        login_button = wait_until_element_visible(driver, By.ID, "idSIButton9")
        login_button.click()

        # انتظار تحميل الصفحة بشكل كامل
        wait_until_page_loaded(driver)

        # النقر على زر تسجيل الدخول
        login_button = wait_until_element_visible(driver, By.ID, "idSIButton9")
        login_button.click()

        # انتظار تحميل الصفحة بشكل كامل
        wait_until_page_loaded(driver)
        

        #gooooooooooooooooooooooooooooooooooooooooooo
        #gooooooooooooooooooooooooooooooooooooooooooo
        
            
        def gooo():
        
            #إستيراد الصفحة
            driver.get("https://app.ofppt-langues.ma/gw/api/saml/init?idp=https://sts.windows.net/dae54ad7-43df-47b7-ae86-4ac13ae567af/")
            wait_until_page_loaded(driver)
        
            def start():
                global message_box
                # إخفاء نافذة go
                message_box.withdraw()
                

                # Perform the main repeating process
                progress_bar_numbers = driver.find_element(By.CLASS_NAME, "progress-bar-numbers")
                progress_text = progress_bar_numbers.text
                numbers = progress_text.split(' / ')
                number_of_repeats = int(numbers[1].strip())
                print (number_of_repeats)
                answers_list = []

                # جمع الإجابات المحفوظة

                

                for i in range(number_of_repeats):
                    wait_until_page_loaded(driver)

                    # النقر على زر المتابعة
                    continue_button = wait_until_element_visible(driver, By.CLASS_NAME, "btn.footer-button-bar-btn")
                    continue_button.click()
                   
                    # ابحث عن العنصر <span> المناسب باستخدام المحدد CSS
                    answer_field = wait_until_element_visible(driver, By.CSS_SELECTOR, ".input-answer.input-answer-is-correct")

                    # استخرج قيمة النص من العنصر <span> المحدد
                    snap_value = answer_field.text

                    # أضف القيمة إلى قائمة الإجابات
                    answers_list.append(snap_value)
                    print(answer_field.text)

                    # النقر على زر المتابعة
                    continue_button = wait_until_element_visible(driver, By.CLASS_NAME, "btn.footer-button-bar-btn")
                    continue_button.click()

                
                # انتظار تحميل الصفحة بشكل كامل بعد الانتهاء
                wait_until_page_loaded(driver)

                r_button = wait_until_element_visible(driver, By.CSS_SELECTOR, ".btn.center-content.btn-normal.btn-primary.btn-primary-ghost.btn-is-pill")
                r_button.click()

                wait_until_page_loaded(driver)

                rr_button = wait_until_element_visible(driver, By.CSS_SELECTOR, ".btn.center-content.btn-normal.btn-primary.false.is-full-width-only-mobile.btn-is-pill")
                rr_button.click()

                wait_until_page_loaded(driver)

                # لإدخال الإجابات المحفوظة سابقا
                for i in range(len(answers_list)):
                    wait_until_page_loaded(driver)

                    # العثور على حقل الإجابة وإدخال القيمة من قائمة الإجابات
                    answer_field = wait_until_element_visible(driver, By.CSS_SELECTOR, ".question-input.question-input-is-active")
                    answer_field.send_keys(answers_list[i])

                    # النقر على الزر للمتابعة
                    continue_button = wait_until_element_visible(driver, By.CSS_SELECTOR, "button.btn.footer-button-bar-btn")
                    continue_button.click()

                    

                    # النقر مرة أخرى على الزر للمتابعة بعد إدخال القيمة
                    continue_button = wait_until_element_visible(driver, By.CSS_SELECTOR, "button.btn.footer-button-bar-btn")
                    continue_button.click()

                    



                
                print(Back.GREEN + 'DONE ! ! !')
                time.sleep(3)
                gooo()
                print("إختر تمرينا آخر")
                
        



            def gow():
                    global message_box
                    # إنشاء نافذة فرعية
                    message_box = tk.Toplevel(root)
                    message_box.title("Proceed")
                    
                    # جعل النافذة الفرعية فعالة وتعطيل التفاعل مع النوافذ الأخرى
                    message_box.grab_set()

                    # مركبات النافذة الفرعية
                    message_label = tk.Label(message_box, text="Click 'GO' when ready to proceed")
                    message_label.pack(padx=10, pady=10)
                    go_button = tk.Button(message_box, text="GO", command=start)
                    go_button.pack()

            gow()
             
        gooo()
        

    except Exception as e:
        print(f"حدث خطأ أثناء تشغيل البرنامج: {e}")



    


    print(Fore.BLACK + ' ')


######################################################################





# إنشاء نافذة
root = tk.Tk()
root.title("Altissia OFPPT Hack")
root.configure(bg="#2b2b2b")  # تعيين لون الخلفية للوضع الظلام
root.iconbitmap("./icon.ico")

frame = tk.Frame(root, bg="#2b2b2b")  # تعيين لون الخلفية للوضع الظلام
frame.pack(padx=10, pady=10)

# إنشاء مسمى وحقل إدخال للبريد الإلكتروني
email_label = tk.Label(frame, text="Your OFPPT Email:", bg="#2b2b2b", fg="white")
email_label.grid(row=0, column=0, sticky="w")
email_entry = tk.Entry(frame)
email_entry.grid(row=0, column=1, padx=5, pady=5)

# إنشاء مسمى وحقل إدخال لكلمة المرور
password_label = tk.Label(frame, text="Password:", bg="#2b2b2b", fg="white")
password_label.grid(row=1, column=0, sticky="w")
password_entry = tk.Entry(frame, show="*")
password_entry.grid(row=1, column=1, padx=5, pady=5)

# إنشاء زر "Start"
start_button = tk.Button(frame, text="Start", command=starttt, bg="#4CAF50", fg="white")
start_button.grid(row=2, columnspan=2, pady=10)

# إنشاء زر "Update"
update_button = tk.Button(frame, text="Update", command=update_function, bg="#008CBA", fg="white")
update_button.grid(row=3, columnspan=2, pady=5)

# إنشاء نص يحمل قيمة vrs
vrs_label = tk.Label(frame, text=f"Version: {vrs}", bg="#2b2b2b", fg="white")
vrs_label.grid(row=4, columnspan=2)

custom_font = ("Arial", 12, "bold")
# إنشاء نص يحمل قيمة vrs
the_label = tk.Label(frame, text=f"by @Aio.tv1", bg="#2b2b2b", fg="white", font=custom_font)
the_label.grid(row=5, columnspan=2)
root.mainloop()
######################################################################
exit = input(" ")
